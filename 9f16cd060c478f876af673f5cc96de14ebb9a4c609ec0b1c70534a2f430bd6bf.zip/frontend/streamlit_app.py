import streamlit as st
import requests
import json
import time
from datetime import datetime

# Configure page with medical-grade styling
st.set_page_config(
    page_title="MediCode AI - Intelligent Clinical Coding Assistant",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for professional medical UI
st.markdown("""
<style>
    /* Import medical-grade fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global styling */
    .main-header {
        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
        padding: 2rem;
        border-radius: 15px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
        box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
    }
    
    .main-title {
        font-family: 'Inter', sans-serif;
        font-size: 2.5rem;
        font-weight: 700;
        margin-bottom: 0.5rem;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .main-subtitle {
        font-family: 'Inter', sans-serif;
        font-size: 1.2rem;
        font-weight: 400;
        opacity: 0.9;
        margin-bottom: 1rem;
    }
    
    .impact-banner {
        background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
        font-weight: 600;
        box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);
    }
    
    .patient-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 15px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        border-left: 5px solid #3b82f6;
    }
    
    .suggestion-card {
        background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .suggestion-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    
    .high-value {
        border-left: 5px solid #dc2626;
    }
    
    .medium-value {
        border-left: 5px solid #f59e0b;
    }
    
    .standard-value {
        border-left: 5px solid #10b981;
    }
    
    .ai-thinking {
        background: linear-gradient(135deg, #fef3c7 0%, #fbbf24 100%);
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        color: #92400e;
        font-weight: 500;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.8; }
        100% { opacity: 1; }
    }
    
    .confidence-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-left: 0.5rem;
    }
    
    .confidence-high {
        background: #dcfce7;
        color: #166534;
    }
    
    .confidence-medium {
        background: #fef3c7;
        color: #92400e;
    }
    
    .workflow-step {
        background: #f1f5f9;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
        border-left: 4px solid #3b82f6;
    }
    
    .metric-container {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
        border: 1px solid #e5e7eb;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 0.75rem 2rem;
        font-weight: 600;
        font-size: 1.1rem;
        box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
        transition: all 0.2s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
    }
    
    .physician-tip {
        background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
        border: 1px solid #93c5fd;
        border-radius: 10px;
        padding: 1rem;
        margin: 1rem 0;
        color: #1e40af;
    }
    
    .processing-status {
        background: #f0f9ff;
        border: 1px solid #0ea5e9;
        border-radius: 8px;
        padding: 1rem;
        margin: 1rem 0;
        color: #0c4a6e;
        text-align: center;
    }
</style>
""", unsafe_allow_html=True)

# Main header with impact messaging
st.markdown("""
<div class="main-header">
    <div class="main-title">🏥 MediCode AI</div>
    <div class="main-subtitle">Intelligent Clinical Coding Assistant</div>
    <div style="font-size: 1rem; margin-top: 1rem;">
        🎯 Empowering physicians with AI-driven HCC coding accuracy<br>
        💰 Helping recover $20B+ in annual healthcare reimbursements
    </div>
</div>
""", unsafe_allow_html=True)

# Social impact banner
st.markdown("""
<div class="impact-banner">
    🌟 Transforming Healthcare Documentation • Improving Patient Care • Reducing Administrative Burden
</div>
""", unsafe_allow_html=True)

# Create the main workflow
tab1, tab2, tab3 = st.tabs(["📝 Patient Analysis", "📊 Insights Dashboard", "🎓 Learning Center"])

with tab1:
    # Patient input section with empathetic design
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown('<div class="patient-card">', unsafe_allow_html=True)
        st.markdown("### 👨‍⚕️ Patient Encounter Information")
        
        # Patient context
        col_a, col_b = st.columns(2)
        with col_a:
            patient_age = st.number_input("Patient Age", min_value=0, max_value=120, value=67, help="Age affects HCC risk stratification")
            encounter_type = st.selectbox(
                "Encounter Type",
                ["Annual Wellness Visit", "Follow-up Visit", "Hospital Admission", "Consultation", "Emergency Visit"],
                help="Different encounters have varying HCC capture opportunities"
            )
        
        with col_b:
            patient_id = st.text_input("Patient ID (Optional)", placeholder="12345", help="For tracking and follow-up")
            visit_date = st.date_input("Visit Date", value=datetime.now().date())
        
        # Primary diagnosis with smart suggestions
        st.markdown("#### 🔍 Primary Diagnosis")
        diagnosis = st.text_input(
            "What is the primary condition you're treating?",
            placeholder="e.g., Type 2 Diabetes with diabetic nephropathy",
            help="Be as specific as possible - complications and severity matter for HCC coding"
        )
        
        # Clinical notes with guided prompts
        st.markdown("#### 📋 Clinical Documentation")
        
        # Helpful prompts for physicians
        st.markdown("""
        <div class="physician-tip">
            <strong>💡 Documentation Tips for Optimal HCC Capture:</strong><br>
            • Include specific complications and comorbidities<br>
            • Note disease severity and functional impact<br>
            • Document monitoring, evaluation, assessment, and treatment (MEAT)<br>
            • Mention relevant lab values, imaging results, or clinical indicators
        </div>
        """, unsafe_allow_html=True)
        
        notes = st.text_area(
            "Clinical Notes & Observations",
            placeholder="""Example: 67-year-old patient with uncontrolled type 2 diabetes mellitus. HbA1c elevated at 9.2%. Patient exhibits signs of diabetic nephropathy with proteinuria and declining eGFR (45 ml/min). Currently on metformin and lisinopril. Discussed medication compliance and dietary modifications...""",
            height=150,
            help="Include comprehensive clinical details for accurate AI analysis"
        )
        
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        # Real-time guidance panel
        st.markdown("### 🤖 AI Assistant Guidance")
        
        if diagnosis:
            st.markdown(f"""
            <div class="workflow-step">
                <strong>✅ Diagnosis Detected:</strong><br>
                {diagnosis}
            </div>
            """, unsafe_allow_html=True)
        
        if notes and len(notes) > 50:
            words = len(notes.split())
            st.markdown(f"""
            <div class="workflow-step">
                <strong>📝 Documentation Quality:</strong><br>
                {words} words • {'Comprehensive' if words > 100 else 'Adequate' if words > 50 else 'Brief'}
            </div>
            """, unsafe_allow_html=True)
        
        # Quick stats
        st.markdown("### 📈 Quick Impact Preview")
        st.markdown("""
        <div class="metric-container">
            <strong>Potential HCC Categories</strong><br>
            <span style="font-size: 1.5rem; color: #3b82f6;">5-8</span>
        </div>
        """, unsafe_allow_html=True)
        
        st.markdown("""
        <div class="metric-container" style="margin-top: 1rem;">
            <strong>Est. Annual Impact</strong><br>
            <span style="font-size: 1.5rem; color: #059669;">$3,500 - $8,200</span>
        </div>
        """, unsafe_allow_html=True)

    # Analysis button with enhanced UX
    st.markdown("---")
    
    col_btn1, col_btn2, col_btn3 = st.columns([2, 1, 2])
    with col_btn2:
        analyze_button = st.button("🚀 Analyze with AI", use_container_width=True, type="primary")

    # Analysis processing and results
    if analyze_button:
        if diagnosis and notes:
            # Multi-stage processing with visual feedback
            progress_container = st.container()
            
            with progress_container:
                st.markdown("""
                <div class="ai-thinking">
                    🧠 AI Analysis in Progress...
                </div>
                """, unsafe_allow_html=True)
                
                # Simulate AI processing stages
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                # Stage 1: NLP Processing
                status_text.text("🔍 Analyzing clinical notes with natural language processing...")
                progress_bar.progress(25)
                time.sleep(1)
                
                # Stage 2: Condition Extraction
                status_text.text("🎯 Extracting conditions and identifying HCC opportunities...")
                progress_bar.progress(50)
                time.sleep(1)
                
                # Stage 3: Code Mapping
                status_text.text("📋 Mapping to optimal ICD-10 codes and HCC categories...")
                progress_bar.progress(75)
                time.sleep(1)
                
                # Stage 4: Impact Calculation
                status_text.text("💰 Calculating financial impact and confidence scores...")
                progress_bar.progress(100)
                time.sleep(0.5)
                
                # Clear progress indicators
                progress_bar.empty()
                status_text.empty()
            
            # Prepare data for API
            payload = {
                "diagnosis": diagnosis,
                "notes": notes,
                "patient_age": patient_age,
                "encounter_type": encounter_type
            }
            
            try:
                # Call backend API
                response = requests.post("http://127.0.0.1:8000/analyze", json=payload)
                
                if response.status_code == 200:
                    data = response.json()
                    
                    # Success message with animation
                    st.balloons()
                    st.success("✅ AI Analysis Complete! Here are your optimized coding recommendations:")
                    
                    # Results section with enhanced UI
                    col1, col2 = st.columns([3, 2])
                    
                    with col1:
                        st.markdown("### 🎯 HCC Code Recommendations")
                        
                        suggestions = data.get("suggestions", [])
                        if suggestions:
                            for i, suggestion in enumerate(suggestions):
                                # Determine value category for styling
                                annual_impact = suggestion.get('annual_impact', 0)
                                if annual_impact > 2000:
                                    value_class = "high-value"
                                    priority = "🔥 HIGH PRIORITY"
                                elif annual_impact > 1000:
                                    value_class = "medium-value"
                                    priority = "⚡ MEDIUM PRIORITY"
                                else:
                                    value_class = "standard-value"
                                    priority = "✅ STANDARD"
                                
                                # Confidence score simulation
                                confidence = 95 - (i * 5)  # Decreasing confidence
                                if confidence > 90:
                                    conf_class = "confidence-high"
                                    conf_text = "HIGH CONFIDENCE"
                                else:
                                    conf_class = "confidence-medium"
                                    conf_text = "MEDIUM CONFIDENCE"
                                
                                st.markdown(f"""
                                <div class="suggestion-card {value_class}">
                                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                                        <h4 style="margin: 0; color: #1e40af;">📋 {suggestion['icd_code']}</h4>
                                        <div>
                                            <span class="confidence-badge {conf_class}">{conf_text}</span>
                                            <span style="margin-left: 0.5rem; font-weight: bold; color: #dc2626;">{priority}</span>
                                        </div>
                                    </div>
                                    
                                    <p style="font-size: 1.1rem; font-weight: 500; color: #374151; margin-bottom: 1rem;">
                                        {suggestion['description']}
                                    </p>
                                    
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                                        <div>
                                            <strong style="color: #3b82f6;">HCC Category:</strong><br>
                                            <span style="font-size: 1.1rem;">{suggestion['hcc_category']}</span>
                                        </div>
                                        <div>
                                            <strong style="color: #3b82f6;">RAF Value:</strong><br>
                                            <span style="font-size: 1.1rem; color: #059669;">{suggestion['raf_value']}</span>
                                        </div>
                                    </div>
                                    
                                    <div style="background: #f8fafc; padding: 1rem; border-radius: 8px;">
                                        <strong style="color: #059669;">💰 Annual Financial Impact: ${suggestion['annual_impact']:,}</strong>
                                    </div>
                                </div>
                                """, unsafe_allow_html=True)
                        else:
                            st.info("No specific HCC recommendations found. Consider adding more clinical detail.")
                    
                    with col2:
                        st.markdown("### 🔍 AI Analysis Summary")
                        
                        # Extracted conditions
                        conditions = data.get("extracted_conditions", [])
                        if conditions:
                            st.markdown("**📋 Identified Conditions:**")
                            for condition in conditions:
                                st.markdown(f"• {condition}")
                        
                        # Total impact calculation
                        total_impact = sum(s.get('annual_impact', 0) for s in suggestions)
                        
                        st.markdown(f"""
                        <div class="metric-container" style="margin-top: 2rem;">
                            <h3 style="color: #059669; margin-bottom: 0.5rem;">💰 Total Potential Impact</h3>
                            <div style="font-size: 2rem; font-weight: bold; color: #059669;">
                                ${total_impact:,}
                            </div>
                            <div style="color: #6b7280; margin-top: 0.5rem;">
                                Annual reimbursement opportunity
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Documentation quality score
                        doc_score = min(100, len(notes.split()) * 2)  # Simple scoring
                        st.markdown(f"""
                        <div class="metric-container" style="margin-top: 1rem;">
                            <h4 style="color: #3b82f6; margin-bottom: 0.5rem;">📝 Documentation Quality</h4>
                            <div style="font-size: 1.5rem; font-weight: bold; color: {'#059669' if doc_score > 80 else '#f59e0b' if doc_score > 60 else '#dc2626'};">
                                {doc_score}%
                            </div>
                            <div style="color: #6b7280; margin-top: 0.5rem;">
                                {'Excellent' if doc_score > 80 else 'Good' if doc_score > 60 else 'Needs Improvement'}
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                
                else:
                    st.error("❌ Error analyzing data. Please try again.")
                    
            except requests.exceptions.ConnectionError:
                st.error("❌ Cannot connect to backend. Please ensure the API server is running.")
                st.info("**Development Note**: Make sure to run `uvicorn app:app --reload` in a separate terminal.")
            except Exception as e:
                st.error(f"❌ An error occurred: {str(e)}")
        else:
            st.warning("⚠️ Please enter both diagnosis and clinical notes to proceed with AI analysis.")

with tab2:
    st.markdown("### 📊 Practice Analytics Dashboard")
    
    # Mock dashboard for demo
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Monthly HCC Captures", "47", "↑ 23%")
    with col2:
        st.metric("Avg. Documentation Score", "87%", "↑ 12%")
    with col3:
        st.metric("Revenue Recovery", "$45,200", "↑ $8,400")
    with col4:
        st.metric("Time Saved", "8.5 hrs", "↑ 3.2 hrs")
    
    st.markdown("*Analytics dashboard would show real practice improvement metrics*")

with tab3:
    st.markdown("### 🎓 HCC Coding Education Center")
    
    st.markdown("""
    #### 📚 Quick Reference Guide
    
    **Most Common HCC Categories:**
    - **HCC 18**: Diabetes with chronic complications
    - **HCC 85**: Congestive heart failure  
    - **HCC 96**: Ischemic heart disease
    - **HCC 108**: Vascular disease
    - **HCC 111**: Chronic kidney disease
    
    **MEAT Documentation Requirements:**
    - **M**onitor: How are you tracking the condition?
    - **E**valuate: What tests/assessments are you doing?
    - **A**ssess: What's your clinical judgment?
    - **T**reat: What interventions are you providing?
    """)

# Enhanced sidebar with physician resources
with st.sidebar:
    st.markdown("### 🏥 Physician Resources")
    
    st.markdown("""
    **🎯 Today's Impact:**
    - Analyses performed: 1
    - Potential revenue identified: $8,200
    - Time saved: 45 minutes
    """)
    
    st.markdown("---")
    
    st.markdown("""
    ### 📞 Quick Support
    - 📧 support@medicode-ai.com
    - 📱 1-800-MEDICODE  
    - 💬 Live chat available
    """)
    
    st.markdown("### 🔒 Privacy & Security")
    st.markdown("✅ HIPAA Compliant\n✅ SOC 2 Certified\n✅ End-to-end Encryption")
    
    # Feedback section
    st.markdown("### 💭 Feedback")
    feedback = st.text_area("How can we improve?", height=100)
    if st.button("Submit Feedback"):
        st.success("Thank you for your feedback!")